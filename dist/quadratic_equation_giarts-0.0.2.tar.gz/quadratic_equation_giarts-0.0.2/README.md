# Example Package

This is a small quadratic equation solver package.